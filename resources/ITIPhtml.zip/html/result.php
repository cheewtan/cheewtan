<!DOCTYPE html>
<html>

<head>

	<link rel="stylesheet" href="style.css">
</head>


<body>
<div id="page-wrapper">

<h1> Result: </h1>
<?php


//Start the session
session_start();

//Access your POST variables
//$new_extension='txt';
$probId = $_SESSION['POST'];
$choice=$_SESSION['POST1'];
//$probId=$probId1. '.' . $new_extension;
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 
$filename = '/var/www/html/program/current/'.$probId;

ignore_user_abort(true);
		set_time_limit(0);
 $cmd = "./program/Xitip/Xitip program/current/$probId $choice";
   exec($cmd,$output,$return_val);
?>
<p>  </p>


<br>

 Go back to home page  &nbsp <button id="myButton" class="float-left submit-button" >Home</button>

<script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "index.html";
    };
</script>
<?php

function cost_time($filename){
 
  $handle = @fopen($filename,'r');
  if($handle) {
    if( ($start = fgets($handle,100)) != null ){
      if( ($end = fgets($handle,100)) != null){
         $time_record = 'Started at:<br>'.$start.'<br>Finished at:<br>'.$end.'<br>';
      }
      else{
         $time_record = 'still running';
      }
    }else{
      $time_record = 'no start time find';
    }
  }else{
    $time_record = 'no time file exists';
  }
  return $time_record;
  
}

function print_file($filename){

   $handle = @fopen($filename, "r");
   if ($handle) {
      while (($buffer = fgets($handle, 4096)) !== false) {
        echo $buffer."<br>";
      }
      if (!feof($handle)) {
        echo "Error: unexpected fgets() fail\n";
      }
      fclose($handle);
   }
}
function print_result($probId){
   $dir = "/var/www/html/program/Xitip/result/$probId/";
   $pre_url = 'program/Xitip/result/'.$probId.'/';
   $html_start = '<a href="';
   $html_end = '" download="">Download</a>';
   $filename = $dir.'glpk1.lp';
   if(file_exists($filename)){
       echo "<h3>Linear Program:</h3>";
       //print_file($filename); 
      $html = $html_start.$pre_url.'glpk1.lp'.$html_end."<br>";
	   echo $html;
   }
   $filename = $dir.'dual_lp';
   if(file_exists($filename)){
       echo "<h3>Dual Linear Program: </h3>";
       //print_file($filename);
       $html = $html_start.$pre_url.'dual_lp'.$html_end."<br>";
	   echo $html;
   }
   $filename = $dir.'solution.txt';
   if(file_exists($filename)){
       echo "<h3>Solution: </h3>";
       //print_file($filename);
       $html = $html_start.$pre_url.'solution.txt'.$html_end."<br>";
	   echo $html;
   }
   $filename = $dir.'proof.txt';
   if(file_exists($filename)){
       echo "<h3>Proof: </h3>";
	   $html = $html_start.$pre_url.'proof.txt'.$html_end."<br>";
	   echo $html;
	   echo "<br>";
       print_file($filename);
       
   }
   $filename = $dir.'proof_sp.txt';
   if(file_exists($filename)){
       echo "<h3>Shortest Proof: </h3>";
	   $html = $html_start.$pre_url.'proof_sp.txt'.$html_end."<br>";
	   echo $html;
	   echo "<br>";
       print_file($filename);
       
   }
   $filename = $dir.'disproof.txt';
   if(file_exists($filename)){
       echo "<h3>Disproof: </h3>";
	   $html = $html_start.$pre_url.'disproof.txt'.$html_end."<br>";
	   echo $html;
	   echo "<br>";
       print_file($filename);
       
   }
}

function download_file($file){

  if(file_exists($file)){
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($file));
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
   }
}
  
 
  
  
$filename = '/var/www/html/program/current/'.$probId;

if(file_exists($filename)){
	
	$filename = '/var/www/html/program/Xitip/result/'.$probId;
   $timefilename = $filename.'/time.txt';
   
   if(file_exists($timefilename)){
     $time = cost_time($timefilename);
     if(strlen($time)>=20){
		 echo "<br>";
		 echo "<br>";
		 echo '<font size=5>Problem '.$probId.' is solved as follows:</font>';
	     echo "<h3>Time: </h3>";
         echo $time."<br>";
        print_result($probId);
     }else{
        echo "<h2>The problem is being solved!</h2>";
		
     }
   }
   else{
	echo "<br>";
	echo "<br>"; 
	echo "<h2>This problem cannot be solved!</h2>";
	echo "<br>";
	echo "<br>";
	}
}
?>

</div>
</body>
</html>

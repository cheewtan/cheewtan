<html>
<body>

Objective funcion: <?php echo $_POST["Objective"]; ?><br>
Constraints: <?php echo $_POST["constraints"]; ?>

</body>
</html>
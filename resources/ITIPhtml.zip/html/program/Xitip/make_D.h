#ifndef _DEBUG_H_
#define _DEBUG_H_

#define DEBUG_ITIP  1

#if DEBUG_ITIP
#define print_debug(str)  printf(str)
#define print2_debug(str,x) printf(str,x)
#else
#define print_debug(str) ;
#define print2_debug(str,x) ;
#endif/*DEBUG_ITIP_ITIP*/

void make_D(int number_vars, int *length, int **indices, double **values); /*number_constraints indicates the number of rows already present in the linear program*/

#endif/* _DEBUG_H_ */

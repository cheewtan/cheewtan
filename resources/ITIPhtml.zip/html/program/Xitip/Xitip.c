/* 
 *  Xitip -- Information theoretic inequality Prover. 
 *  Xitip.c is the main C program to produce the GTK 2+ based
 *  graphical front end.
 *  Copyright (C) 2007 Rethnakaran Pulikkoonattu,
 *                     Etienne Perron, 
 *                     Suhas Diggavi. 
 *                     Information Processing Group, 
 *                     Ecole Polytechnique Federale de Lausanne,
 *                     EPFL, Switzerland, CH-1005
 *                     Email: rethnakaran.pulikkoonattu@epfl.ch
 *                            etienne.perron@epfl.ch
 *                            suhas.diggavi@epfl.ch
 *                     http://ipg.epfl.ch
 *                     http://xitip.epfl.ch
 *  Dependent utilities:
 *  The program uses two other softwares
 *  1) The ITIP software developed by Raymond Yeung 
 *  2) qsopt, a linear programming solver developed by David Applegate et al.
 *  The details of the licensing terms of the above mentioned software shall 
 *  be obtained from the respective websites and owners. 
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

/*
Write your Objective functions along with Constraints into a textfile like data.txt or data.dat
in Terminal, write:
./Xitip data.dat 0
and if you want Shortest Proof:
./Xitip data.dat 1
*/
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <stdint.h>
#include "itip1.h"
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#define MAX_LINES 100
#define LINE_MAXCHARS 1024

int readInput(char * inputFileName, char ** expressions);
char * remove_white_space(char *string);
static void callITIP(char *inputFileName, char ** expressions, int length, char *choice);

int main(int argc, const char * argv[]) {
    if(argc != 3){
        printf("You should call Xitip [inputFile] [Shortest_Proof].\n");
        return 0;
    }
    char *expressions[MAX_LINES];
	char *choice, choice1;
    int numberOfLines = readInput((char *)argv[1], expressions);
    if(numberOfLines == -1)
        return -1;
    char * relativePath = basename((char *)argv[1]);
	//choice1 shows that user wants shortest proof or not
    choice1 =argv[2];
	//printf("choice1 = %c\n", choice1);
	  callITIP(relativePath, expressions, numberOfLines, argv[2]);
    return 0;
}
    
int readInput(char * inputFileName, char ** expressions){
    FILE* fp;
    char *strLine;
    int counter = 0;
    if((fp = fopen(inputFileName, "r")) == NULL){
        printf("Error: input file does not exist!\n");
        return -1;
    }
    while(counter < MAX_LINES){
        strLine = (char *)malloc(LINE_MAXCHARS*sizeof(char));
        fgets(strLine, LINE_MAXCHARS, fp);
        expressions[counter++] = strLine;
		
		
    }
    fclose(fp);
    return counter;
}

char * remove_white_space(char *string){
  char *temp_string;
  int k, length,ktemp;
  
  length = strlen(string)+1;
  temp_string = (char *)malloc(length*sizeof(char));
  
  ktemp = 0;
  for(k=0;k<length;k++){
    if(string[k] == ' ' || string[k] == '\t' || string[k] == '\n'){
      /* do nothing */
    }
    else{
      temp_string[ktemp] = string[k];
      ktemp++;
    }
  }

  return temp_string;
}

static void callITIP(char * inputFileName, char ** expressions, int length, char *choice){

	int result, exprCount = 0;
	char *expressionsClean[length];
	char *testString;
	int i,j;
    for(i = 0; i < length; i++){
    	expressions[i] = (char *)remove_white_space(expressions[i]);
		//printf("%d\n",strlen(expressions[i]));
    	/*skip the expression if it is empty:*/
    	if(strlen(expressions[i])>1){
      		expressionsClean[exprCount++] = expressions[i];
    	}
		
		
  	}
	 
	
 	//char *myResult=(char *)malloc( 10000*sizeof(char));
		int myResult=(int)malloc( sizeof(int)); //edited     
	printf("Information Inequality Result:\n");

	if ((strlen(expressions[0]))){
	    
		result = itip1(inputFileName, expressionsClean,exprCount, choice, myResult); //result = itip1(inputFileName, expressionsClean,exprCount, choice, myResult);
		printf("DONE\n");
	    if(result ==-2){
			printf ("Syntaxt ERROR: Re-enter the information expression \n %s", expressions[0]);
	  	}
	  	else if(result == 5){
			printf("ERROR: The constraints cannot be inequalities.\n");
	  	}
	  	else if(result == 3){
			printf("ERROR: The number of distinct random variables cannot be more than 52.\n");
	  	}
	  	else if(result == 4){
			printf("ERROR: Some of the random variables are too long. The maximal length allowed for a single random variable name is 300.\n");
	  	}
	  	else if(result <=-3){
			printf ("Syntax ERROR:Constraint %d has wrong syntax.\n Please re-enter\n %s\n with the correct syntax\n",-1*result-2, expressions[-1*result-2]);
	  	}
	  	else if(result==-1)
			printf("You have entered a basic Shannon measure. These measures, without sign are always non negative! Basic Information measures are in the form of entropies (single, joint or conditional) and mutual information(unconditional or conditional). For example the following are basic shannon measures (for 3 random variables X,Y and Z) which are non-nagative by definition\nH(X)>=0, \nH(X,Y)>=0, \nI(X;Y)>=0, \nI(X;Y|Z)>=0,\nH(X|Y)>=0. \nIf you have entered an expression as a single negative constant times these basic Shannon measure, then the inequality is always Non true, beacuase of the non negativity of Shannon measures", NULL);
	  	else if(result==1){
			testString = "TRUE";
			if (exprCount>1){
				printf ("The information expression (with the given constraints)\n %s is\n %s \n %s", expressions[0], testString,  myResult);
			}
			else{
				printf ("The information expression (without any further constraint)\n %s is\n %s \n %s", expressions[0], testString,  myResult);
			}
	  	}
	  	else if(result==0){
			testString ="Not solvable by Xitip: This implies either of the following situations\n 1.\t The inequality is NOT true\n or\n 2.\t This expression is a non-Shannon type inequality which is true.\n \t Currently Xitip is equipped enough to verify only the Shannon type inequalities";
			if (exprCount>1){
				printf ("The information expression (with the given constraints)\n %s is\n %s \n %s", expressions[0], testString,  myResult);
			}
			else{
				printf ("The information expression (without any further constraint)\n %s is\n %s \n %s", expressions[0], testString,  myResult);
			}
	  	}
	  	else{
			printf("An unexpected error has occurred.");
	  	}
  	}
  	else {
    	printf ("The information expression is EMPTY!\n You must enter a valid information expression in the first field");
  	}
}

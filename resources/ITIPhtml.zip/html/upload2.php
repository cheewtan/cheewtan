<!DOCTYPE html>
<html>




<head>

	<link rel="stylesheet" href="style.css">
</head>
<body>
<div id="page-wrapper">
<h1> Welcome to Xitip </h1>

<?php

// ----------------------------------------------------------------------------------------------------
// - Display Errors
// ----------------------------------------------------------------------------------------------------
ini_set('display_errors', 'On');
ini_set('html_errors', 0);

// ----------------------------------------------------------------------------------------------------
// - Error Reporting
// ----------------------------------------------------------------------------------------------------
error_reporting(-1);

// ----------------------------------------------------------------------------------------------------
// - Shutdown Handler
// ----------------------------------------------------------------------------------------------------
function ShutdownHandler()
{
    if(@is_array($error = @error_get_last()))
    {
        return(@call_user_func_array('ErrorHandler', $error));
    };

    return(TRUE);
};

register_shutdown_function('ShutdownHandler');

// ----------------------------------------------------------------------------------------------------
// - Error Handler
// ----------------------------------------------------------------------------------------------------
function ErrorHandler($type, $message, $file, $line)
{
    $_ERRORS = Array(
        0x0001 => 'E_ERROR',
        0x0002 => 'E_WARNING',
        0x0004 => 'E_PARSE',
        0x0008 => 'E_NOTICE',
        0x0010 => 'E_CORE_ERROR',
        0x0020 => 'E_CORE_WARNING',
        0x0040 => 'E_COMPILE_ERROR',
        0x0080 => 'E_COMPILE_WARNING',
        0x0100 => 'E_USER_ERROR',
        0x0200 => 'E_USER_WARNING',
        0x0400 => 'E_USER_NOTICE',
        0x0800 => 'E_STRICT',
        0x1000 => 'E_RECOVERABLE_ERROR',
        0x2000 => 'E_DEPRECATED',
        0x4000 => 'E_USER_DEPRECATED'
    );

    if(!@is_string($name = @array_search($type, @array_flip($_ERRORS))))
    {
        $name = 'E_UNKNOWN';
    };

    return(print(@sprintf("%s Error in file \xBB%s\xAB at line %d: %s\n", $name, @basename($file), $line, $message)));
};

$old_error_handler = set_error_handler("ErrorHandler");


function execInBackground($cmd) { 
    if (substr(php_uname(), 0, 7) == "Windows"){ 
        pclose(popen("start /B ". $cmd, "r"));  
    } 
    else { 
        exec($cmd . " > /dev/null &");   
    } 
} 

//--------------------------------------------------------------------------------------
$uploadOk = 1;
$id = time()+mt_rand(1, 50);

$myfile = fopen("$id", "w") or die("Unable to open file!");
$txt = $_POST['objective'];
if (isset($_POST['sp'])){
	$choice=1;	
}
else{$choice=0;}
fwrite($myfile, $txt);
$txt ="\n";
fwrite($myfile, $txt);
$txt = $_POST['constraints'];
fwrite($myfile, $txt);
fclose($myfile);
echo "<h2>File uploaded successfully!</h2>";
echo "<h2>Your problem ID is ${id}.</h2>";
echo "<h2>This problem is being solved. Please wait for the result.</h2>";
$cmd = "mv $id  program/current";
exec($cmd);
		echo "Note:  For the large-scale problem, it takes longer time to obtain the result. You can record your problem ID and check the result later.";
		
		echo "<br>";


		//Start the session
		session_start();

		//Dump your POST variables
		$_SESSION['POST'] = $id ;
		$_SESSION['POST1'] = $choice ;
		$test=$_SESSION['POST'];
		//Redirect the user to the next page
		header('Refresh: 2; url=result.php');

echo "<br>";

?>



Go back to home page  &nbsp <button id="myButton" class="float-left submit-button" >Home</button>
 <script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "index.html";
    };
</script>  

</div>
</body>
</html>


